# Stockwise — Interactive Product Inventory & Analytics Dashboard

**EWB EduTech JavaScript Capstone Project**

## Overview
Stockwise is a responsive browser-based product inventory dashboard built with HTML, CSS, and vanilla JavaScript. It starts with the brief's example products (Laptop, Mouse, Monitor) and supports adding/removing products, searching, filtering, sorting, live financial summaries, category breakdowns, report copying, and CSV export.

## Run the project
1. Extract the ZIP file.
2. Open `index.html` in a modern browser (Chrome, Edge, or Firefox).
3. No installation, account, API key, or build step is required.
4. Add products with the form. Inventory changes are saved in the browser's `localStorage`.

Internet access is only needed if you want the optional Google Fonts to load; the app itself works without them.

## Included files
- `index.html` — page structure
- `style.css` — responsive dashboard styling
- `script.js` — inventory logic and analytics
- `README.md` — setup and feature notes
- `SUBMISSION_NOTES.md` — feature mapping and demo checklist

## Features
- Product creation and removal
- Input validation and duplicate-name checks
- Budget / Standard / Premium classification
- Search, category filter, and sorting
- Total inventory value, product count, average price, affordable-item count
- Category breakdown and affordable products list
- Formatted report with copy action
- CSV export
- Custom tax and discount calculator (discount first, then tax)
- Browser localStorage persistence
- Responsive layout for desktop and mobile

## Assignment concept mapping
- Variables and types: `const`, `let`, strings, numbers, arrays, objects
- Input and type conversion: form inputs and `Number()`
- Conditional logic: `if...else`, `switch`
- Loops and flow control: `for`, `forEach()`, `break`, early-return validation
- Functions and scope: regular functions and arrow functions
- Arrays: `filter()`, `map()`, `reduce()`, `find()`, `sort()`
- Data persistence: `localStorage` with JSON serialization
- Reporting: generated text report and CSV file

## Demo scenario
The initial products are:
- Laptop — $800 (Premium)
- Mouse — $25 (Budget)
- Monitor — $150 (Standard)

Expected initial total: **$975**. Affordable items under $200: **Mouse** and **Monitor**.

## Notes
- Currency is shown in USD to match the assignment's sample output.
- Data is stored only in the current browser profile; clearing browser data may remove saved inventory.
- This project is a learning/demo application, not a production inventory management system.
