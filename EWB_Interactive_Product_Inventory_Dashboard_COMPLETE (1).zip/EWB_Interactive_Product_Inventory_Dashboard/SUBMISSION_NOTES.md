# Submission Notes

## Project title
Interactive Product Inventory & Analytics Dashboard (Stockwise)

## What is included from the supplied brief
- Product records stored as an array of objects
- Product input and explicit numeric conversion
- Input validation
- Budget, Standard, and Premium categories
- Loops and array iteration
- Regular and arrow functions
- `forEach()`, `filter()`, and `map()`
- Total inventory value and affordable-items report

## Enhancements implemented
- Responsive dashboard UI
- Add and remove products
- Search, category filtering, and sorting
- Live summary cards and category breakdown
- Duplicate-name validation
- Browser persistence using localStorage
- Copyable report and downloadable CSV
- Custom tax and discount calculator with input validation

These enhancements are additions to the assignment brief, not claims about a pre-existing product.

## Quick test checklist
1. Open `index.html`; confirm the default products and $975 total.
2. Add `Headphones` at `49.99`; confirm it is categorized as Budget and the totals update.
3. Try adding `Mouse` again; confirm duplicate validation appears.
4. Try a blank name, blank price, zero, or negative price; confirm validation blocks the submission.
5. Search for `mon`; confirm Monitor is shown.
6. Filter by Standard; confirm Monitor is shown initially.
7. Sort by price low-to-high; confirm the order updates.
8. Remove a product; confirm the summary and report update.
9. Refresh the browser; confirm the current inventory is restored.
10. Export CSV and open the downloaded file to verify its columns.
11. Select a product in the tax/discount calculator, try 10% discount and 8% tax, then change the percentages and confirm the final price updates.
12. Try a percentage below 0 or above 100; confirm the calculator displays a validation message.

## Before submitting
- Add your own name/college details only if the submission form asks for them.
- Test the app in your browser and take screenshots of the dashboard, add-product form, and updated analytics if screenshots are requested.
- Follow the submission Google Form's instructions once EWB shares it.
