/*
  Stockwise — Interactive Product Inventory & Analytics Dashboard
  EWB EduTech JavaScript Capstone
  Concepts demonstrated: let/const, data types, type conversion, conditions,
  switch, loops, functions, arrow functions, block scope, arrays/objects,
  forEach(), filter(), map(), localStorage, CSV export and report generation.
*/
"use strict";

const STORAGE_KEY = "stockwise_inventory_v1";
const DEFAULT_INVENTORY = [
  { id: 1, name: "Laptop", price: 800 },
  { id: 2, name: "Mouse", price: 25 },
  { id: 3, name: "Monitor", price: 150 }
];

let inventory = loadInventory();
let nextId = inventory.reduce((largest, product) => Math.max(largest, product.id), 0) + 1;
let toastTimer;

// Load saved inventory, or start with the sample products.
function loadInventory() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (error) {
    console.warn("Saved inventory could not be loaded:", error);
  }
  return DEFAULT_INVENTORY.map(product => ({ ...product }));
}

function saveInventory() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(inventory));
  } catch (error) {
    console.warn("Browser storage is unavailable:", error);
  }
}

// Price tiers: Budget < $50, Standard < $200, Premium >= $200.
// switch is used deliberately to demonstrate the assessment requirement.
function getCategory(price) {
  if (price < 50) return "Budget";
  if (price < 200) return "Standard";
  switch (true) {
    case price >= 200:
      return "Premium";
    default:
      return "Standard";
  }
}

const formatMoney = amount => new Intl.NumberFormat("en-US", {
  style: "currency", currency: "USD"
}).format(amount);

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

function setFormMessage(message, type = "") {
  const element = document.getElementById("formMessage");
  element.textContent = message;
  element.className = `form-message ${type}`;
}

function addProduct(event) {
  event.preventDefault();
  const nameInput = document.getElementById("productName");
  const priceInput = document.getElementById("productPrice");
  const name = nameInput.value.trim();
  const price = Number(priceInput.value); // explicit type conversion

  if (!name) {
    setFormMessage("Please enter a product name.", "error");
    nameInput.focus();
    return;
  }
  if (priceInput.value.trim() === "" || !Number.isFinite(price) || price <= 0) {
    setFormMessage("Enter a valid price greater than zero.", "error");
    priceInput.focus();
    return;
  }

  // Case-insensitive duplicate check using a loop and break.
  let duplicate = false;
  for (let i = 0; i < inventory.length; i++) {
    if (inventory[i].name.toLowerCase() === name.toLowerCase()) {
      duplicate = true;
      break;
    }
  }
  if (duplicate) {
    setFormMessage("A product with that name already exists.", "error");
    return;
  }

  inventory.push({ id: nextId++, name, price });
  saveInventory();
  document.getElementById("categoryFilter").value = "All";
  document.getElementById("searchInput").value = "";
  document.getElementById("sortSelect").value = "name";
  renderDashboard();
  document.getElementById("productForm").reset();
  setFormMessage(`${name} was added successfully.`, "success");
  showToast(`${name} added to inventory`);
}

function deleteProduct(id) {
  const product = inventory.find(item => item.id === id);
  if (!product) return;
  inventory = inventory.filter(item => item.id !== id);
  saveInventory();
  renderDashboard();
  showToast(`${product.name} removed`);
}

function getVisibleProducts() {
  const searchTerm = document.getElementById("searchInput").value.trim().toLowerCase();
  const selectedCategory = document.getElementById("categoryFilter").value;
  const sortOrder = document.getElementById("sortSelect").value;

  let products = inventory.filter(product => {
    // continue demonstrates skipping products that don't match the search.
    if (searchTerm && !product.name.toLowerCase().includes(searchTerm)) return false;
    if (selectedCategory !== "All" && getCategory(product.price) !== selectedCategory) return false;
    return true;
  });

  switch (sortOrder) {
    case "priceAsc":
      products.sort((a, b) => a.price - b.price);
      break;
    case "priceDesc":
      products.sort((a, b) => b.price - a.price);
      break;
    default:
      products.sort((a, b) => a.name.localeCompare(b.name));
  }
  return products;
}

function renderInventory() {
  const body = document.getElementById("inventoryBody");
  const products = getVisibleProducts();
  body.replaceChildren();

  products.forEach(product => {
    const row = document.createElement("tr");
    const category = getCategory(product.price);
    const initials = product.name.split(/\s+/).map(part => part[0]).join("").slice(0, 2).toUpperCase();

    const productCell = document.createElement("td");
    const productWrap = document.createElement("div");
    productWrap.className = "product-cell";
    const avatar = document.createElement("span");
    avatar.className = "product-avatar";
    avatar.textContent = initials;
    const textWrap = document.createElement("div");
    const productName = document.createElement("div");
    productName.className = "product-name";
    productName.textContent = product.name;
    const sub = document.createElement("div");
    sub.className = "product-sub";
    sub.textContent = `Product ID: ${product.id}`;
    textWrap.append(productName, sub);
    productWrap.append(avatar, textWrap);
    productCell.append(productWrap);

    const priceCell = document.createElement("td");
    priceCell.className = "price-cell";
    priceCell.textContent = formatMoney(product.price);

    const categoryCell = document.createElement("td");
    const badge = document.createElement("span");
    badge.className = `badge ${category.toLowerCase()}`;
    badge.textContent = category;
    categoryCell.append(badge);

    const actionCell = document.createElement("td");
    actionCell.style.textAlign = "right";
    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.className = "delete-btn";
    deleteButton.textContent = "Remove";
    deleteButton.setAttribute("aria-label", `Remove ${product.name}`);
    deleteButton.addEventListener("click", () => deleteProduct(product.id));
    actionCell.append(deleteButton);

    row.append(productCell, priceCell, categoryCell, actionCell);
    body.append(row);
  });

  document.getElementById("emptyState").classList.toggle("hidden", products.length !== 0);
  document.getElementById("showingCount").textContent = `Showing ${products.length} of ${inventory.length} products`;
}

function renderStats() {
  const total = inventory.reduce((sum, product) => sum + product.price, 0);
  const average = inventory.length ? total / inventory.length : 0;
  const affordable = inventory.filter(product => product.price < 200);

  document.getElementById("totalValue").textContent = formatMoney(total);
  document.getElementById("productCount").textContent = String(inventory.length);
  document.getElementById("averagePrice").textContent = formatMoney(average);
  document.getElementById("affordableCount").textContent = String(affordable.length);
}

function renderCategoryBreakdown() {
  const container = document.getElementById("categoryBreakdown");
  container.replaceChildren();
  const categories = ["Budget", "Standard", "Premium"];
  const counts = categories.map(category => ({
    category,
    count: inventory.filter(product => getCategory(product.price) === category).length
  }));
  const maxCount = Math.max(1, ...counts.map(item => item.count));

  counts.forEach(item => {
    const row = document.createElement("div");
    row.className = "breakdown-row";
    const label = document.createElement("span");
    label.className = "tier";
    label.textContent = item.category;
    const track = document.createElement("div");
    track.className = "bar-track";
    const fill = document.createElement("div");
    fill.className = `bar-fill ${item.category.toLowerCase()}`;
    fill.style.width = `${(item.count / maxCount) * 100}%`;
    track.append(fill);
    const count = document.createElement("span");
    count.className = "count";
    count.textContent = String(item.count);
    row.append(label, track, count);
    container.append(row);
  });
}

function renderAffordableList() {
  const container = document.getElementById("affordableList");
  container.replaceChildren();
  const affordable = inventory.filter(product => product.price < 200).sort((a, b) => a.price - b.price);

  if (!affordable.length) {
    const empty = document.createElement("p");
    empty.className = "empty-affordable";
    empty.textContent = "No products are currently priced under $200.";
    container.append(empty);
    return;
  }

  affordable.forEach(product => {
    const item = document.createElement("div");
    item.className = "affordable-item";
    const left = document.createElement("div");
    left.className = "affordable-left";
    const avatar = document.createElement("span");
    avatar.className = "product-avatar";
    avatar.textContent = product.name.charAt(0).toUpperCase();
    const labels = document.createElement("div");
    const name = document.createElement("strong");
    name.textContent = product.name;
    const category = document.createElement("small");
    category.textContent = getCategory(product.price);
    labels.append(name, category);
    left.append(avatar, labels);
    const price = document.createElement("span");
    price.className = "affordable-price";
    price.textContent = formatMoney(product.price);
    item.append(left, price);
    container.append(item);
  });
}

function renderReport() {
  const total = inventory.reduce((sum, product) => sum + product.price, 0);
  const affordableNames = inventory.filter(product => product.price < 200).map(product => product.name);
  const formattedProducts = inventory.map(product => `${product.name.toUpperCase()}: ${formatMoney(product.price)}`);
  const report = [
    "STOCKWISE — INVENTORY REPORT",
    `Products: ${inventory.length}`,
    `Total inventory value: ${formatMoney(total)}`,
    `Average product price: ${formatMoney(inventory.length ? total / inventory.length : 0)}`,
    `Affordable items (under $200): ${JSON.stringify(affordableNames)}`,
    `Formatted product list: ${JSON.stringify(formattedProducts)}`,
    "",
    "Product details:",
    ...inventory.map(product => `• ${product.name} — ${formatMoney(product.price)} — ${getCategory(product.price)}`)
  ];
  document.getElementById("reportOutput").textContent = report.join("\n");
}


function renderCalculatorOptions() {
  const select = document.getElementById("calculatorProduct");
  const previousValue = select.value;
  select.replaceChildren();
  inventory.forEach(product => {
    const option = document.createElement("option");
    option.value = String(product.id);
    option.textContent = `${product.name} — ${formatMoney(product.price)}`;
    select.append(option);
  });
  if (inventory.some(product => String(product.id) === previousValue)) {
    select.value = previousValue;
  }
  updatePriceCalculation();
}

function updatePriceCalculation() {
  const select = document.getElementById("calculatorProduct");
  const selectedId = Number(select.value);
  const product = inventory.find(item => item.id === selectedId);
  const discountInput = document.getElementById("discountRate");
  const taxInput = document.getElementById("taxRate");
  const discountRate = Number(discountInput.value);
  const taxRate = Number(taxInput.value);
  const message = document.getElementById("calculatorMessage");

  if (!product) {
    document.getElementById("calcOriginal").textContent = formatMoney(0);
    document.getElementById("calcDiscount").textContent = `−${formatMoney(0)}`;
    document.getElementById("calcTax").textContent = formatMoney(0);
    document.getElementById("calcFinal").textContent = formatMoney(0);
    message.textContent = "Add a product to use the calculator.";
    message.className = "form-message";
    return;
  }

  if (!Number.isFinite(discountRate) || !Number.isFinite(taxRate) ||
      discountInput.value.trim() === "" || taxInput.value.trim() === "" ||
      discountRate < 0 || discountRate > 100 || taxRate < 0 || taxRate > 100) {
    message.textContent = "Enter discount and tax percentages between 0 and 100.";
    message.className = "form-message error";
    return;
  }

  const discountAmount = product.price * discountRate / 100;
  const discountedPrice = product.price - discountAmount;
  const taxAmount = discountedPrice * taxRate / 100;
  const finalPrice = discountedPrice + taxAmount;

  document.getElementById("calcOriginal").textContent = formatMoney(product.price);
  document.getElementById("calcDiscount").textContent = `−${formatMoney(discountAmount)}`;
  document.getElementById("calcTax").textContent = formatMoney(taxAmount);
  document.getElementById("calcFinal").textContent = formatMoney(finalPrice);
  message.textContent = "Price preview updated.";
  message.className = "form-message success";
}

function renderDashboard() {
  renderInventory();
  renderStats();
  renderCategoryBreakdown();
  renderAffordableList();
  renderReport();
  renderCalculatorOptions();
}

function exportCSV() {
  if (!inventory.length) {
    showToast("There are no products to export.");
    return;
  }
  const rows = [["ID", "Product Name", "Price (USD)", "Category"]];
  inventory.forEach(product => rows.push([product.id, product.name, product.price.toFixed(2), getCategory(product.price)]));
  const csv = rows.map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "stockwise-inventory.csv";
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  showToast("CSV report exported");
}

async function copyReport() {
  const report = document.getElementById("reportOutput").textContent;
  try {
    await navigator.clipboard.writeText(report);
    showToast("Inventory report copied");
  } catch (error) {
    // Fallback for browsers that don't allow clipboard access from local files.
    const textArea = document.createElement("textarea");
    textArea.value = report;
    document.body.append(textArea);
    textArea.select();
    const copied = document.execCommand("copy");
    textArea.remove();
    showToast(copied ? "Inventory report copied" : "Could not copy report; select and copy it manually.");
  }
}

// Wire up the interactive controls.
document.getElementById("productForm").addEventListener("submit", addProduct);
document.getElementById("searchInput").addEventListener("input", renderInventory);
document.getElementById("categoryFilter").addEventListener("change", renderInventory);
document.getElementById("sortSelect").addEventListener("change", renderInventory);
document.getElementById("exportBtn").addEventListener("click", exportCSV);
document.getElementById("copyReportBtn").addEventListener("click", copyReport);
document.getElementById("calculatorProduct").addEventListener("change", updatePriceCalculation);
document.getElementById("discountRate").addEventListener("input", updatePriceCalculation);
document.getElementById("taxRate").addEventListener("input", updatePriceCalculation);
document.getElementById("topAddBtn").addEventListener("click", () => {
  document.getElementById("productName").focus();
  document.getElementById("add-panel").scrollIntoView({ behavior: "smooth", block: "center" });
});

// First render. The sample values match the assignment's expected inventory.
renderDashboard();
